echo 'This content was replaced by pre-init script.' > ${HTTPD_APP_ROOT}/src/index.html
